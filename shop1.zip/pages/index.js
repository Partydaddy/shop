
export default function Home() {
  return (
    <main>
      <h1>Willkommen im Tumbler Shop</h1>
      <p>Produktauswahl folgt...</p>
    </main>
  );
}
